from django.db import models

# Create your models here.


class PaiHang(models.Model):
    name = models.CharField(max_length=16)
    fenshu = models.IntegerField(max_length=32)

