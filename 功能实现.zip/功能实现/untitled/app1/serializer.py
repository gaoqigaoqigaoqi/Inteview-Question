from rest_framework.serializers import ModelSerializer

from app1.models import PaiHang


class PaiHangSerializers(ModelSerializer):
    class Meta:
        model = PaiHang
        fields = "__all__"