import ujson
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response
from rest_framework.views import APIView

from app1.models import PaiHang
from app1.serializer import PaiHangSerializers


class User(APIView):

        def get(self,request):
                objs = PaiHang.objects.all().order_by('fenshu').reverse()[:5]
                data = PaiHangSerializers(objs,many=True)
                return Response({
                    'users':data.data
                })

        @csrf_exempt
        def post(self,request):
                fenshu = request.POST.get('fenshu')
                name = request.POST.get('name')
                paihang_obj = PaiHang(name=name)
                if paihang_obj:
                        paihang_obj.fenshu = fenshu
                        paihang_obj.name = str(name)
                        paihang_obj.save()
                        data = PaiHangSerializers(paihang_obj)
                else:
                    paihang_obj = PaiHang(name=name)
                    paihang_obj.fenshu = fenshu
                    paihang_obj.name = str(name)
                    paihang_obj.save()
                    data = PaiHangSerializers(paihang_obj)
                # print(data.data)
                return Response({
                        'status':'ok',
                        'obj':data.data
                })

